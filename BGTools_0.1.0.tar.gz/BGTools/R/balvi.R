balvi <- function(x,y,max.iter,err,hyper1=1,hyper2=1e-04,uni=TRUE){
  if (!is.matrix(x)) stop("x must be a matrix")
  if (!is.numeric(y)) stop("y must be a numeric vector")
  if (nrow(x)!=length(y)) stop("nrow(x)!=length(y)")
  if (sum(is.na(x))!=0) stop(" x has missing value(s)")
  ## constants
  p = ncol(x)
  n = nrow(x)
  ss <- colSums(x^2)

  ## Initial values
  Eb0 = 0
  Eb0b0 = 0
  Eb = rep(0,p)
  Ebb = 0.5*rep(1,p)
  Etau0 = 1/0.5
  Etau = 1/0.5*rep(1,p)
  Einvtau = 1/Etau
  varb0 = 1/Etau0
  varb = 1/(Etau0*Etau)
  Elambda =rep(0.5,p)
  r = y-Eb0-x%*%Eb
  L = 0
  count = 0
  for (i in 1:max.iter){
    Eb0old = Eb0
    Lold = L


    Eb0 = Eb0+1/n*sum(r)
    r = r+Eb0old-Eb0
    varb0 = 1/n/Etau0


    if (uni) {
      varb = (Etau0*Etau+ss*Etau0)^(-1)
    } else {
      varb = (Etau+ss*Etau0)^(-1)
    }
    c.res <- .C("calc_b",as.double(x), Eb, r, Etau0, varb, ss, p, n,PACKAGE = 'BGTools')
    Eb <- c.res[[2]]
    r <- c.res[[3]]
    Eb0b0 = varb0+Eb0^2
    Ebb = varb+Eb^2


    if (uni){
      alpha1 = n+p
      beta1 = sum(Ebb*Etau) + sum(r^2)+n*varb0+sum(ss*varb)
      Etau0 = alpha1/beta1
    } else {
      alpha1 = n/2
      beta1 = 0.5*(sum(r^2)+n*varb0+sum(ss*varb))
      Etau0 = alpha1/beta1
    }

    if (uni){
      Etau = sqrt(Elambda/(Etau0*Ebb))
      lambda0 = Elambda
      Einvtau = 1/lambda0+1/Etau
    } else {
      Etau = sqrt(Elambda/Ebb)
      lambda0 = Elambda
      Einvtau = 1/lambda0+1/Etau
    }

    alpha2 = 1+ hyper1
    beta2 = Einvtau/2+ hyper2
    Elambda = alpha2/beta2

    ## lower bound
    if (uni){
      L = -(n-p-1)*log(2*pi)/2+(2*p+1)/2-p*log(2)-sum(Ebb*Etau*Etau0)/2+log(varb0)/2+sum(log(varb))/2+p*log(hyper2^hyper1/gamma(hyper1))-alpha1*log(beta1)+lgamma(alpha1)-sum(log(lambda0))/2-sum(alpha2*log(beta2)-lgamma(alpha2))+0.5*sum(lambda0*Einvtau);
    } else {
      L = -(n-p-1)*log(2*pi)/2+(2*p+1)/2-p*log(2)-sum(Ebb*Etau)/2+log(varb0)/2+sum(log(varb))/2+p*log(hyper2^hyper1/gamma(hyper1))-alpha1*log(beta1)+lgamma(alpha1)-sum(log(lambda0))/2-sum(alpha2*log(beta2)-lgamma(alpha2))+0.5*sum(lambda0*Einvtau);
    }
    if (abs(L-Lold)/abs(L)<err){
      count = i
      break
    }
  }
  res = list(Eb0=Eb0,EandV=cbind(Eb,varb),sigma0=1/Etau0,Elambda=Elambda,iter=i)
  return(res)

}

