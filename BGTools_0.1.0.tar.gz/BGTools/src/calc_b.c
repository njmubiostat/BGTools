#include <math.h>
  void calc_b(double *x, double *eb, double *r, double *etau0, double *varb, double *ss, int *p, int *n)
  {
    int i, j;
    double eboldj=0.0, ebt=0.0;
    for (j=0;j < *p ;j++ )
    {
      eboldj = eb[j];
      for (i=0;i < *n ; i++)
      {
        ebt += r[i] * x[i + j * *n];
      }
      eb[j] = (eb[j] * ss[j] + ebt) * *etau0 * varb[j];
      for (i=0;i< *n ; i++)
      {
        r[i] += x[i + j * *n] * (eboldj - eb[j]);
      }
      ebt = 0.0;
    }
  }
